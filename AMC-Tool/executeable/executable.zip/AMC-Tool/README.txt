Just add this folder to Path.
Then you can use the following command in CLI:
AMC-Tool {PATH TO YOUR .mp4}